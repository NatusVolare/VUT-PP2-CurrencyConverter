Final XPA-PP2 project for the Winter 2024 semester.

By; Jeffrey R. Dotson

Purpose of the Project: 
4.Currency exchange rate calculator. The program reads current exchange rates from the internet and converts currencies specified by the user. The program saves history of exchanges to the file. Exchange rates are displayed in time; search for maximum - minimum - average exchange rates are provided.

Final Build: 02.12.2024 - 13:51